<?php
namespace Aws\AutoScalingPlans\Exception;

use Aws\Exception\AwsException;

/**
 * Represents an error interacting with the **AWS Auto Scaling Plans** service.
 */
class AutoScalingPlansException extends AwsException {}
