<?php
// This file was auto-generated from sdk-root/src/data/backup-gateway/2021-01-01/paginators-1.json
return [ 'pagination' => [ 'ListGateways' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Gateways', ], 'ListHypervisors' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Hypervisors', ], 'ListVirtualMachines' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'VirtualMachines', ], ],];
