<?php
// This file was auto-generated from sdk-root/src/data/amplifybackend/2020-08-11/paginators-1.json
return [ 'pagination' => [ 'ListBackendJobs' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Jobs', ], ],];
