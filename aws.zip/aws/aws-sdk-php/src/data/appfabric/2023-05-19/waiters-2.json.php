<?php
// This file was auto-generated from sdk-root/src/data/appfabric/2023-05-19/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
