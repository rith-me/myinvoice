---
title: v8
slogan: Associate files with Eloquent models.
githubUrl: https://github.com/spatie/laravel-medialibrary
branch: v8
---
