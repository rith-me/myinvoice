---
title: Responsive images
weight: 4
---
