---
title: Changelog
weight: 7
---

All notable changes to `laravel-backup` are documented in [the changelog on GitHub](https://github.com/spatie/laravel-backup/blob/master/CHANGELOG.md).
