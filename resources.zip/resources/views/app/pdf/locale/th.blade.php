<style type="text/css">
    @font-face {
        font-family: 'THSarabunNew';
        font-style: normal;
        font-weight: normal;
        src: url("{{ resource_path('static/fonts/THSarabunNew.ttf') }}") format('truetype');
    }

    @font-face {
        font-family: 'THSarabunNew';
        font-style: normal;
        font-weight: bold;
        src: url("{{ resource_path('static/fonts/THSarabunNew-Bold.ttf') }}") format('truetype');
    }

    @font-face {
        font-family: 'THSarabunNew';
        font-style: italic;
        font-weight: normal;
        src: url("{{ resource_path('static/fonts/THSarabunNew-Italic.ttf') }}") format('truetype');
    }

    @font-face {
        font-family: 'THSarabunNew';
        font-style: italic;
        font-weight: bold;
        src: url("{{ resource_path('static/fonts/THSarabunNew-BoldItalic.ttf') }}") format('truetype');
    }

    body {
        font-family: "THSarabunNew", sans-serif !important;
    }

</style>
