@component('mail::message')
# Test Email from Crater

{{ $my_message }}

@endcomponent
