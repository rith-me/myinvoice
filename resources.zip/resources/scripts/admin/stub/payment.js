export default {
  maxPayableAmount: Number.MAX_SAFE_INTEGER,
  selectedCustomer: '',
  currency: null,
  currency_id: '',
  customer_id: '',
  payment_number: '',
  payment_date: '',
  amount: 0,
  invoice_id: '',
  notes: '',
  payment_method_id: '',
  customFields: [],
  fields: []
}
