export default {
  name: '',
  tax_type_id: 0,
  type: 'GENERAL',
  amount: null,
  percent: null,
  compound_tax: false,
}
