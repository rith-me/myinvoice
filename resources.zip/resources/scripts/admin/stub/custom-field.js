export default {
  id: null,
  label: null,
  type: null,
  name: null,
  default_answer: null,
  is_required: false,
  placeholder: null,
  model_type: null,
  order: 1,
  options: [],
}
