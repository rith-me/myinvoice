<template>
  <router-view />

  <BaseDialog />
</template>
