<template>
  <svg viewBox="0 0 225 50" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M211.738 32.1659V27.7768C214.619 24.947 218.409 23.3831 224.397 23.1597V11.6916C218.939 11.6916 214.998 13.4043 211.738 16.1597V12.2873H199.576C199.507 12.9433 199.472 13.609 199.472 14.2828C199.472 22.3755 204.546 29.3041 211.738 32.1659Z"
      fill="url(#paint0_linear_499_29)"
    />
    <path
      d="M211.738 36.1165C206.645 34.4592 202.327 31.1297 199.459 26.7902V48.4045H211.738V36.1165Z"
      fill="url(#paint1_linear_499_29)"
    />
    <path
      d="M16.0297 48.8865C19.2962 46.1641 21.7924 42.5768 23.1519 38.4848C25.3401 37.6506 26.8605 35.8956 27.2881 33.5853H38.8855C38.0517 42.8939 30.2443 49.2237 20.087 49.2237C18.6861 49.2237 17.3305 49.1085 16.0297 48.8865Z"
      fill="url(#paint2_linear_499_29)"
    />
    <path
      d="M20.087 11.4682C17.9247 11.4682 15.8704 11.7426 13.9591 12.26C17.5644 14.6466 20.4567 17.9932 22.2562 21.9269C24.9219 22.5899 26.8043 24.4928 27.2881 27.1065H38.8855C38.0517 17.798 30.2443 11.4682 20.087 11.4682Z"
      fill="url(#paint3_linear_499_29)"
    />
    <path
      d="M0 30.3087C0 38.354 4.52386 44.7328 11.4781 47.5909C14.7638 45.5212 17.3803 42.5159 18.9382 38.9578C14.3944 38.4418 11.6732 34.8526 11.6732 30.3087C11.6732 26.0841 14.0253 22.7398 18.0075 21.8837C16.0622 18.4948 13.104 15.7418 9.53648 14.0211C3.69365 17.1959 0 23.0881 0 30.3087Z"
      fill="url(#paint4_linear_499_29)"
    />
    <path
      d="M69.9096 23.1597V11.6916C64.452 11.6916 60.5104 13.4043 57.251 16.1597V12.2873H44.9714V48.4045H57.251V27.7768C60.1314 24.947 63.9214 23.3831 69.9096 23.1597Z"
      fill="url(#paint5_linear_499_29)"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M113.912 48.4045V12.2873H101.633V14.2235C98.9038 12.5107 95.5686 11.4682 91.5512 11.4682C81.6214 11.4682 73.2833 19.5108 73.2833 30.3087C73.2833 41.0322 81.6214 49.1492 91.5512 49.1492C95.5686 49.1492 98.9038 48.1067 101.633 46.3939V48.4045H113.912ZM93.9768 39.2449C88.974 39.2449 85.3356 35.2981 85.3356 30.3087C85.3356 25.3193 88.974 21.298 93.9768 21.298C96.7056 21.298 99.3586 22.1172 101.633 24.7236V35.8938C99.3586 38.5002 96.7056 39.2449 93.9768 39.2449Z"
      fill="url(#paint6_linear_499_29)"
    />
    <path
      d="M151.738 47.7343L150.374 37.5321C147.645 38.0534 145.598 38.4258 143.855 38.4258C140.217 38.4258 138.094 36.6385 138.094 32.9896V22.6384H150.601V12.2873H138.094V0H125.815V12.2873H118.614V22.6384H125.815V33.3619C125.815 43.1173 131.727 49.5216 140.596 49.5216C144.234 49.5216 146.963 49.2237 151.738 47.7343Z"
      fill="url(#paint7_linear_499_29)"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M193.36 29.564C193.36 18.6916 185.25 11.4682 174.562 11.4682C162.813 11.4682 155.005 19.3618 155.005 30.3087C155.005 41.33 163.04 49.2237 175.092 49.2237C184.188 49.2237 191.238 44.5322 192.981 37.0853H180.853C179.792 38.7236 177.821 39.6917 175.244 39.6917C170.544 39.6917 167.967 37.1598 166.982 33.8832H193.209L193.133 33.6598C193.36 32.3193 193.36 30.9044 193.36 29.564ZM174.562 20.7767C178.503 20.7767 181.156 22.8618 181.839 26.8087H166.83C167.74 23.1597 170.393 20.7767 174.562 20.7767Z"
      fill="url(#paint8_linear_499_29)"
    />
    <defs>
      <linearGradient
        id="paint0_linear_499_29"
        x1="-2.72961e-07"
        y1="22.9922"
        x2="224.397"
        y2="22.9922"
        gradientUnits="userSpaceOnUse"
      >
        <stop :stop-color="darkColor" />
        <stop offset="1" :stop-color="lightColor" />
      </linearGradient>
      <linearGradient
        id="paint1_linear_499_29"
        x1="-2.72961e-07"
        y1="22.9922"
        x2="224.397"
        y2="22.9922"
        gradientUnits="userSpaceOnUse"
      >
        <stop :stop-color="darkColor" />
        <stop offset="1" :stop-color="lightColor" />
      </linearGradient>
      <linearGradient
        id="paint2_linear_499_29"
        x1="-2.72961e-07"
        y1="22.9922"
        x2="224.397"
        y2="22.9922"
        gradientUnits="userSpaceOnUse"
      >
        <stop :stop-color="darkColor" />
        <stop offset="1" :stop-color="lightColor" />
      </linearGradient>
      <linearGradient
        id="paint3_linear_499_29"
        x1="-2.72961e-07"
        y1="22.9922"
        x2="224.397"
        y2="22.9922"
        gradientUnits="userSpaceOnUse"
      >
        <stop :stop-color="darkColor" />
        <stop offset="1" :stop-color="lightColor" />
      </linearGradient>
      <linearGradient
        id="paint4_linear_499_29"
        x1="-2.72961e-07"
        y1="22.9922"
        x2="224.397"
        y2="22.9922"
        gradientUnits="userSpaceOnUse"
      >
        <stop :stop-color="darkColor" />
        <stop offset="1" :stop-color="lightColor" />
      </linearGradient>
      <linearGradient
        id="paint5_linear_499_29"
        x1="-2.72961e-07"
        y1="22.9922"
        x2="224.397"
        y2="22.9922"
        gradientUnits="userSpaceOnUse"
      >
        <stop :stop-color="darkColor" />
        <stop offset="1" :stop-color="lightColor" />
      </linearGradient>
      <linearGradient
        id="paint6_linear_499_29"
        x1="-2.72961e-07"
        y1="22.9922"
        x2="224.397"
        y2="22.9922"
        gradientUnits="userSpaceOnUse"
      >
        <stop :stop-color="darkColor" />
        <stop offset="1" :stop-color="lightColor" />
      </linearGradient>
      <linearGradient
        id="paint7_linear_499_29"
        x1="-2.72961e-07"
        y1="22.9922"
        x2="224.397"
        y2="22.9922"
        gradientUnits="userSpaceOnUse"
      >
        <stop :stop-color="darkColor" />
        <stop offset="1" :stop-color="lightColor" />
      </linearGradient>
      <linearGradient
        id="paint8_linear_499_29"
        x1="-2.72961e-07"
        y1="22.9922"
        x2="224.397"
        y2="22.9922"
        gradientUnits="userSpaceOnUse"
      >
        <stop :stop-color="darkColor" />
        <stop offset="1" :stop-color="lightColor" />
      </linearGradient>
    </defs>
  </svg>
</template>

<script setup>
defineProps({
  darkColor: {
    type: String,
    default: 'rgba(var(--color-primary-500), var(--tw-text-opacity))',
  },
  lightColor: {
    type: String,
    default: 'rgba(var(--color-primary-400), var(--tw-text-opacity))',
  },
})
</script>
