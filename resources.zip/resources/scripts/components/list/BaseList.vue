<template>
  <div class="list-none">
    <slot />
  </div>
</template>
<script>
export default {
  name: 'List',
}
</script>
