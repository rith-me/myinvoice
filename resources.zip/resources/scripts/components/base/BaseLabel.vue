<template>
  <label class="text-sm not-italic font-medium leading-5 text-primary-800">
    <slot />
  </label>
</template>
