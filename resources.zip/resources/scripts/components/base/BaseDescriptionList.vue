<template>
  <div class="grid gap-4 mt-5 md:grid-cols-2 lg:grid-cols-3">
    <slot />
  </div>
</template>
