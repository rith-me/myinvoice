<template>
  <div class="flex-1 p-4 md:p-8 flex flex-col">
    <slot />
  </div>
</template>
