<template>
  <div class="flex flex-col">
    <div class="-my-2 overflow-x-auto lg:overflow-visible sm:-mx-6 lg:-mx-8">
      <div class="py-2 align-middle inline-block min-w-full sm:px-4 lg:px-6">
        <div class="overflow-hidden lg:overflow-visible sm:px-2 lg:p-2">
          <slot />
        </div>
      </div>
    </div>
  </div>
</template>

