<template>
  <hr class="w-full text-gray-300" />
</template>
