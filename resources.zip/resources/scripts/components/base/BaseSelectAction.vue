<template>
  <div
    class="
      flex
      items-center
      justify-center
      w-full
      px-6
      py-2
      text-sm
      bg-gray-200
      cursor-pointer
      text-primary-400
    "
  >
    <slot />
  </div>
</template>
