<template>
  <svg viewBox="0 0 1170 20" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M690 4.08004C518 -9.91998 231 4.08004 -6 176.361L231 197.08L1170 219.08C1113.33 175.747 909.275 21.928 690 4.08004Z"
      fill="white"
      fill-opacity="0.1"
    />
  </svg>
</template>
