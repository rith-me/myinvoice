<template>
  <svg
    width="1122"
    height="1017"
    viewBox="0 0 1122 1017"
    preserveAspectRatio="none"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M226.002 466.5C164.935 687.5 188.326 831.5 224.141 1017H1140V-7L0 -109.5C142.5 -7.5 282.085 263.536 226.002 466.5Z"
      fill="url(#paint0_linear)"
      fill-opacity="0.1"
    />
    <defs>
      <linearGradient
        id="paint0_linear"
        x1="649.5"
        y1="-7"
        x2="649.5"
        y2="1017"
        gradientUnits="userSpaceOnUse"
      >
        <stop
          stop-color="rgba(var(--color-primary-500), var(--tw-text-opacity))"
        />
        <stop
          offset="1"
          stop-color="rgba(var(--color-primary-400), var(--tw-text-opacity))"
        />
      </linearGradient>
    </defs>
  </svg>
</template>
