<template>
  <footer
    class="
      fixed
      bottom-0
      flex
      items-center
      justify-end
      w-full
      h-10
      py-2
      pr-8
      text-sm
      font-normal
      text-gray-700
      bg-white
    "
  >
    Powered by
    <a
      href="http://bytefury.com/"
      target="_blank"
      class="pl-1 font-normal text-gray-900"
      >Bytefury
    </a>
  </footer>
</template>
