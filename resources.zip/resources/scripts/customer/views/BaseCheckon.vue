<template>
  <div class="h-10 w-20 bg-gray-100">
    <slot></slot>
  </div>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped>
</style>
