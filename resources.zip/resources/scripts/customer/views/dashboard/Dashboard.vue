<template>
  <BasePage>
    <DashboardStats />
    <DashboardTable />
  </BasePage>
</template>

<script setup>
import DashboardStats from '@/scripts/customer/views/dashboard/DashboardStats.vue'
import DashboardTable from '@/scripts/customer/views/dashboard/DashboardTable.vue'
</script>
